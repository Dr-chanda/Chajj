function giftedtech_0xe6da() {
    const _0xb5dfbc = [
        'offer',
        'AUTO_REJECT_CALLS',
        '513495kmwVwo',
        '1186374SoxrqS',
        '10189553hDqvnA',
        'rejectCall',
        '202557lnRZBn',
        '1002kdiZyC',
        '19033dZDAcU',
        'sendMessage',
        '84yCqPSE',
        'from',
        '10JIYOXK',
        '2122305msmZch',
        'status',
        '72nWZhuK',
        '96308VjyJlC'
    ];
    giftedtech_0xe6da = function () {
        return _0xb5dfbc;
    };
    return giftedtech_0xe6da();
}
function giftedtech_0x5704(_0x3be929, _0x2bc682) {
    const _0xe6dafc = giftedtech_0xe6da();
    return giftedtech_0x5704 = function (_0x5704f6, _0x33ade7) {
        _0x5704f6 = _0x5704f6 - 0x152;
        let _0x31738b = _0xe6dafc[_0x5704f6];
        return _0x31738b;
    }, giftedtech_0x5704(_0x3be929, _0x2bc682);
}
(function (_0x724b2c, _0x1ac5cc) {
    const _0x21e106 = giftedtech_0x5704, _0x39c8d5 = _0x724b2c();
    while (!![]) {
        try {
            const _0x47d0ef = -parseInt(_0x21e106(0x15f)) / 0x1 + -parseInt(_0x21e106(0x15c)) / 0x2 + parseInt(_0x21e106(0x152)) / 0x3 * (parseInt(_0x21e106(0x158)) / 0x4) + -parseInt(_0x21e106(0x155)) / 0x5 + -parseInt(_0x21e106(0x160)) / 0x6 * (parseInt(_0x21e106(0x161)) / 0x7) + -parseInt(_0x21e106(0x157)) / 0x8 * (-parseInt(_0x21e106(0x15b)) / 0x9) + parseInt(_0x21e106(0x154)) / 0xa * (parseInt(_0x21e106(0x15d)) / 0xb);
            if (_0x47d0ef === _0x1ac5cc)
                break;
            else
                _0x39c8d5['push'](_0x39c8d5['shift']());
        } catch (_0x30af24) {
            _0x39c8d5['push'](_0x39c8d5['shift']());
        }
    }
}(giftedtech_0xe6da, 0x6b590));
import giftedtech_0x39266a from '../../set.cjs';
const Callupdate = async (_0x48d71b, _0x219d22) => {
    const _0x5080cc = giftedtech_0x5704;
    for (const _0x4e8e10 of _0x48d71b) {
        if (_0x4e8e10[_0x5080cc(0x156)] === _0x5080cc(0x159) && giftedtech_0x39266a[_0x5080cc(0x15a)]) {
            let _0x111d62 = await _0x219d22[_0x5080cc(0x162)](_0x4e8e10['from'], {
                'text': '*_📞\x20Auto\x20Call\x20Reject\x20Mode\x20Activated\x20by\x20Gifted-Md_*\x20\x0a*_📵\x20No\x20Calls\x20Allowed\x20Dude!_*',
                'mentions': [_0x4e8e10['from']]
            });
            await _0x219d22[_0x5080cc(0x15e)](_0x4e8e10['id'], _0x4e8e10[_0x5080cc(0x153)]);
        }
    }
};
export default Callupdate;